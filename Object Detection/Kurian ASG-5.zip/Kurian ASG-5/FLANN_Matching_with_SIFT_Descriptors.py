import cv2 as cv
i1 = cv.imread('1.jpg')
i2 = cv.imread('2.jpg')
i3 = cv.imread('3.jpg')

img1 = cv.cvtColor(i1, cv.COLOR_BGR2GRAY)
img2 = cv.cvtColor(i2, cv.COLOR_BGR2GRAY)
img3 = cv.cvtColor(i3, cv.COLOR_BGR2GRAY)

# Initiate SIFT detector
sift = cv.SIFT_create()
# find the keypoints and descriptors with SIFT
kp1, des1 = sift.detectAndCompute(img1,None)
kp2, des2 = sift.detectAndCompute(img2,None)
kp3, des3 = sift.detectAndCompute(img3,None)
# FLANN parameters
FLANN_INDEX_KDTREE = 1
index_params = dict(algorithm = FLANN_INDEX_KDTREE, trees = 5)
search_params = dict(checks=50)   # or pass empty dictionary
flann = cv.FlannBasedMatcher(index_params,search_params)

matches1 = flann.match(des1,des2)
matches2 = flann.match(des1,des3)
matches3 = flann.match(des2,des3)
'''
#Try to do it with KNN 
# Need to draw only good matches, so create a mask
matchesMask = [[0,0] for i in range(len(matches1))]
# ratio test as per Lowe's paper
for i,(m,n) in enumerate(matches1):
    if m.distance < 0.7*n.distance:
        matchesMask[i]=[1,0]

draw_params = dict(matchColor = (0,255,0),
                   singlePointColor = (255,0,0),
                   matchesMask = matchesMask,
                   flags = cv.DrawMatchesFlags_DEFAULT)


img3 = cv.drawMatchesKnn(img1,kp1,img2,kp2,matches1,None,**draw_params)
plt.imshow(img3,),plt.show()
'''

matches1 = sorted(matches1, key = lambda x:x.distance)
matches2 = sorted(matches2, key = lambda x:x.distance)
matches3 = sorted(matches3, key = lambda x:x.distance)
# Draw first 50 matches.
result1 = cv.drawMatches(i1,kp1,i2,kp2,matches1[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
result2 = cv.drawMatches(i1,kp1,i3,kp3,matches2[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
result3 = cv.drawMatches(i2,kp2,i3,kp3,matches3[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

result1 = cv.resize(result1, (800, 450))
result2 = cv.resize(result2, (800, 450))
result3 = cv.resize(result3, (800, 450))

cv.imshow("image1 -> image2 SIFT with FLANN Matcher", result1)
cv.imshow("image1 -> image3 SIFT with FLANN Matcher", result2)
cv.imshow("image2 -> image3 SIFT with FLANN Matcher", result3)

key=cv.waitKey(0)
cv.destroyAllWindows()