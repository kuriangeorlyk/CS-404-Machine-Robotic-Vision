import cv2 as cv
i1 = cv.imread('1.jpg')
i2 = cv.imread('2.jpg')
i3 = cv.imread('3.jpg')

img1 = cv.cvtColor(i1, cv.COLOR_BGR2GRAY)
img2 = cv.cvtColor(i2, cv.COLOR_BGR2GRAY)
img3 = cv.cvtColor(i3, cv.COLOR_BGR2GRAY)

# Initiate ORB detector
orb = cv.ORB_create()
# find the keypoints and descriptors with ORB
kp1, des1 = orb.detectAndCompute(img1,None)
kp2, des2 = orb.detectAndCompute(img2,None)
kp3, des3 = orb.detectAndCompute(img3,None)
# FLANN parameters
FLANN_INDEX_LSH = 6
index_params= dict(algorithm = FLANN_INDEX_LSH, table_number = 6, key_size = 12, multi_probe_level = 1)
search_params = dict(checks=50)   # or pass empty dictionary
flann = cv.FlannBasedMatcher(index_params,search_params)

matches1 = flann.match(des1,des2)
matches2 = flann.match(des1,des3)
matches3 = flann.match(des2,des3)

matches1 = sorted(matches1, key = lambda x:x.distance)
matches2 = sorted(matches2, key = lambda x:x.distance)
matches3 = sorted(matches3, key = lambda x:x.distance)

# Draw first 50 matches.
result1 = cv.drawMatches(i1,kp1,i2,kp2,matches1[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
result2 = cv.drawMatches(i1,kp1,i3,kp3,matches2[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
result3 = cv.drawMatches(i2,kp2,i3,kp3,matches3[:50],None,flags=cv.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

result1 = cv.resize(result1, (800, 450))
result2 = cv.resize(result2, (800, 450))
result3 = cv.resize(result3, (800, 450))

cv.imshow("image1 -> image2 ORB with FLANN Matcher", result1)
cv.imshow("image1 -> image3 ORB with FLANN Matcher", result2)
cv.imshow("image2 -> image3 ORB with FLANN Matcher", result3)

key=cv.waitKey(0)
cv.destroyAllWindows()