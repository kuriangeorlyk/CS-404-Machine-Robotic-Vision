#Kurian-Auto Face Detect Attendance
import tkinter as tk
from tkinter import *
import cv2
import csv
import os
import numpy as np
from PIL import Image,ImageTk
import pandas as pd
import datetime
import time

#GUI Window Creating
window = tk.Tk()#Create Instance  for TKINTER MOdule
window.title("AUTO FACE DETECT-Attendance") #Title
window.geometry('1000x620')#size of Window
window.configure(background='White')

#For take images for datasets
def captureTrainImages():
    lbl1 = rollNumberTextBox.get()
    lbl2 = studentNameTextBox.get()
    if lbl1 == '':
        print("Please Enter RollNumer Number!")
    elif lbl2 == '':
        print("Please Enter Name !")
    else:
        try:
            cam = cv2.VideoCapture(0)
            detector = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
            Enrollment = rollNumberTextBox.get()
            Name = studentNameTextBox.get()
            imageCounter = 0
            while (True):
                ret, img = cam.read()
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                faces = detector.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                    imageCounter = imageCounter + 1 #IMGE FILE NAME COUNTER
                    # saving the captured face in the dataset folder
                    cv2.imwrite("TrainingImage/ " + Name + "." + Enrollment + '.' + str(imageCounter) + ".jpg",
                                gray[y:y + h, x:x + w])
                    cv2.imshow('Frame', img)
                # wait for 100 miliseconds
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
                elif imageCounter > 100:# break if the sample number is morethan 100
                    break
            cam.release()
            cv2.destroyAllWindows()
            #WRITING TO StudentDetails.csv
            ts = time.time()
            Date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            Time = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
            row = [Enrollment, Name, Date, Time]
            with open('StudentDetails\StudentDetails.csv', 'a+') as csvFile:
                writer = csv.writer(csvFile, delimiter=',')
                writer.writerow(row)
                csvFile.close()
            res = "Test Images Captured "
            Notification.configure(text=res, bg="#1d353d", width=50, font=('times', 18, 'bold'))
            Notification.place(x=200, y=400)
        except FileExistsError as F:
           print('Student Data already exists')

#For choose subject and fill attendance
def markAttendance():
    def Fillattendances():
        sub=tx.get()
        now = time.time()
        stopTime = now + 10
        if time.time() < stopTime:
            if sub == '': #if Subject name not Enter
                print("Please Enter Subject Name !")#Error Message
            else: #Prediction Starts
                recognizer = cv2.face.LBPHFaceRecognizer_create()
                try:
                    recognizer.read("TrainingImageLabel\Trainner.yml")
                except:
                    print('Model not found,Please train model !')
                haarcascade_OBJ = "haarcascade_frontalface_default.xml" #used to detect only face
                faceCascade = cv2.CascadeClassifier(haarcascade_OBJ)
                df = pd.read_csv("StudentDetails\StudentDetails.csv")#loading data
                cam = cv2.VideoCapture(0)
                font = cv2.FONT_HERSHEY_SIMPLEX
                colNames = ['Enrollment', 'Name', 'Date', 'Time']#Colum name list
                attendance = pd.DataFrame(columns=colNames)#Dtaframe column names
                while True:#infinity Loop
                    ret, im = cam.read()
                    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)#Reade Image Converting To GRAY
                    faces = faceCascade.detectMultiScale(gray, 1.2, 5)
                    for (x, y, w, h) in faces:
                        global Id
                        Id, conf = recognizer.predict(gray[y:y + h, x:x + w])#predicting
                        if (conf <100): #matching the images
                            print(conf)
                            global Subject
                            global aa
                            global date
                            global timeStamp
                            Subject = tx.get()
                            ts = time.time()
                            date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                            timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                            aa = df.loc[df['Enrollment'] == Id]['Name'].values
                            global tt
                            tt = str(Id) + "-" + aa
                            En = '15624031' + str(Id)
                            attendance.loc[len(attendance)] = [Id, aa, date, timeStamp]
                            cv2.rectangle(im, (x, y), (x + w, y + h), (0, 260, 0), 7)
                            cv2.putText(im, str(tt), (x + h, y), font, 1, (255, 255, 0,), 4)
                        else:
                            Id = 'Unknown'
                            tt = str(Id)
                            cv2.rectangle(im, (x, y), (x + w, y + h), (0, 25, 255), 7)
                            cv2.putText(im, str(tt), (x + h, y), font, 1, (0, 25, 255), 4)
                    if time.time() > stopTime:
                        break
                    attendance = attendance.drop_duplicates(['Enrollment'], keep='first')
                    cv2.imshow('Filling attedance..', im)
                    key = cv2.waitKey(30) & 0xff
                    if key == 27:
                        break
                ts = time.time()
                date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
                timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
                Hour, Minute, Second = timeStamp.split(":")
                fileName = "Attendance/" + Subject + "_" + date + "_" + Hour + "-" + Minute + "-" + Second + ".csv"
                attendance = attendance.drop_duplicates(['Enrollment'], keep='first')
                print(attendance)
                attendance.to_csv(fileName, index=False)

                #Create and Store table for Attendance
                date_for_DB = datetime.datetime.fromtimestamp(ts).strftime('%Y_%m_%d')
                DB_Table_name = str( Subject + "_" + date_for_DB + "_Time_" + Hour + "_" + Minute + "_" + Second)

                #Adding Attendace Data to a Table
                import pymysql.connections#Import SQL PACK
                #Connect to the database
                try:
                    global cursor
                    connection = pymysql.connect(host='localhost', user='root', password='', db='Face_reco_fill')
                    cursor = connection.cursor()
                except Exception as e:
                    print(e)

                sql = "CREATE TABLE " + DB_Table_name + """
                (ID INT NOT NULL AUTO_INCREMENT,
                 ENROLLMENT varchar(100) NOT NULL,NAME VARCHAR(50) NOT NULL,
                 DATE VARCHAR(20) NOT NULL,TIME VARCHAR(20) NOT NULL,PRIMARY KEY (ID));
                """
                #INSERTIN DATA TO TABLE After PREDICT
                insert_data =  "INSERT INTO " + DB_Table_name + " (ID,RollNumer,NAME,DATE,TIME) VALUES (0, %s, %s, %s,%s)"
                VALUES = (str(Id), str(aa), str(date), str(timeStamp))
                try:
                    cursor.execute(sql)  #Exicutes Query
                    cursor.execute(insert_data, VALUES)#For insert data into table
                except Exception as ex:
                    print(ex," Error ")
                M = 'Attendance Marked Successfully' #Shows Message to Screen
                Notifica.configure(text=M, bg="#c7e4f2", fg="black", width=33, font=('times', 15, 'bold'))
                Notifica.place(x=80, y=250)# x axis an y axis, placing to window
                cam.release() #stops Camera
                cv2.destroyAllWindows()#close Window

                #Showing Result Frame
                root = tk.Tk()
                root.title("Attendance of " + Subject) #Window Frame
                root.configure(background='snow')
                with open('StudentDetails/StudentDetails.csv', newline="") as file: #opening DATA FILE
                    reader = csv.reader(file)
                    r = 0
                    for col in reader:
                        c = 0
                        for row in col:
                            label = tk.Label(root, width=8, height=1, fg="black", font=('times', 15, ' bold '),bg="lawn green", text=row, relief=tk.RIDGE)
                            label.grid(row=r, column=c)
                            c += 1
                        r += 1
                root.mainloop()
                #print(attendance)

    #Creating window for subject chooser
    windo = tk.Tk()
    windo.title("Prediction Form")
    windo.geometry('580x320')
    windo.configure(background='snow')
    Notifica = tk.Label(windo, text="Attendance filled Successfully", bg="#f0f5f5", fg="white", width=33, height=2, font=('times', 15, 'bold'))

    #Adding Text Boxes and Buttons to Sub Window
    sub = tk.Label(windo, text="Enter Subject :", width=15, height=2, fg="white", bg="#092b42", font=('times', 15, ' bold '))
    sub.place(x=30, y=100)

    tx = tk.Entry(windo, width=20, bg="#e6e9eb", fg="black", font=('times', 23, ' bold '))
    tx.place(x=250, y=105)

    fill_a = tk.Button(windo, text="Mark Attendance", fg="white",command=Fillattendances, bg="#30101f", width=20, height=2, activebackground="Red", font=('times', 15, ' bold '))
    fill_a.place(x=250, y=160)
    windo.mainloop() # its an infinite loop used to run the application

#For train the model(TRAIN IMAGE BUTTON CODE)
def TrainImages():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    global detector
    detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    try:
        global faces,Id
        faces, Id = getImagesAndLabels("TrainingImage")#NEXT FUNCTION -THIS FUNCTION EXTRACTS NAMES FROM IMAGES
    except Exception as e:
        print('please make "TrainingImage" folder & Take Images')

    recognizer.train(faces, np.array(Id))
    try:
        recognizer.save("TrainingImageLabel\Trainner.yml")
    except Exception as e:
        print('Please make "TrainingImageLabel" folder')

    res = "Model Trained"
    Notification.configure(text=res, bg="#1d353d", width=50, font=('times', 18, 'bold'))
    Notification.place(x=200, y=400)

def getImagesAndLabels(path):
    imagePaths = [os.path.join(path, f) for f in os.listdir(path)]
    faceSamples = []
    Ids = []

    for imagePath in imagePaths:
        pilImage = Image.open(imagePath).convert('L')
        imageNp = np.array(pilImage, 'uint8')
        Id = int(os.path.split(imagePath)[-1].split(".")[1])
        faces = detector.detectMultiScale(imageNp)
        for (x, y, w, h) in faces:
            faceSamples.append(imageNp[y:y + h, x:x + w])
            Ids.append(Id)
    return faceSamples, Ids

window.grid_rowconfigure(0, weight=1)
window.grid_columnconfigure(0, weight=1)

#Adding HEADIng LAbels Text Boxes to the Main GUI Window
message = tk.Label(window, text="Auto Face Detect Attendance", bg="#067B97", fg="black", width=40,height=2, font=('times', 30, 'bold'))
message.place(x=25, y=20)
Notification = tk.Label(window, text="Added", bg="Green", fg="white", width=15, height=3, font=('times', 17, 'bold'))
rollNumberLabel = tk.Label(window, text="Roll Number", width=20, height=2, fg="black", bg="#f0f5f5", font=('times', 15, ' bold '))
rollNumberLabel.place(x=200, y=200)

#Checking the the entered Roll number is NUMERIC value or not
def numberValdation(inStr,acttyp):
    if acttyp == '1':
        if not inStr.isdigit():
            return False
    return True
#adding Label & Text Box(Entry) and Labes (Roll Numer & Student Name)
rollNumberTextBox = tk.Entry(window, validate="key", width=20, bg="#eeeee4", fg="black", font=('times', 20, ' bold '))
rollNumberTextBox['validatecommand'] = (rollNumberTextBox.register(numberValdation),'%P','%d')#Validating ENROLMENT NUMBER IS NUMBER OR NOT
rollNumberTextBox.place(x=550, y=210)
studentNameLabel = tk.Label(window, text="Student Name", width=20, fg="black", bg="#f0f5f5", height=2, font=('times', 15, ' bold '))
studentNameLabel.place(x=200, y=300)
studentNameTextBox = tk.Entry(window, width=20,  bg="#eeeee4", fg="black", font=('times', 20, ' bold '))
studentNameTextBox.place(x=550, y=310)

#Adding # Buttons
captureTrainImagesButton = tk.Button(window, text="Capture Test Images",command=captureTrainImages,fg="white"  ,bg="#0b305c"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
captureTrainImagesButton.place(x=90, y=500)
TrainImagesButton = tk.Button(window, text="Train Images",fg="white",command=TrainImages ,bg="#0b305c"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
TrainImagesButton.place(x=390, y=500)
markAttendanceButton = tk.Button(window, text="Mark Attendance",fg="white",command=markAttendance  ,bg="#0b305c"  ,width=20  ,height=3, activebackground = "Red" ,font=('times', 15, ' bold '))
markAttendanceButton.place(x=690, y=500)
window.mainloop()
